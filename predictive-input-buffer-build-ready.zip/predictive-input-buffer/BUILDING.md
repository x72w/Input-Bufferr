# Build status and instructions

This project has not been compiled in the current environment because the Geode SDK and target binaries are not installed. The `mod.json` file parses as valid JSON, but that is not a substitute for a successful native build or in-game testing.

## Build on GitHub (no local SDK needed)

1. Create a new repository on GitHub and upload the contents of this folder (the `src`, `.github`, `mod.json`, and `CMakeLists.txt` items should be at the repository root).
2. Open **Actions** and enable workflows if GitHub prompts you.
3. Run **Build Mod** using **Run workflow**, or push a commit to trigger it.
4. Wait for all platform jobs and the **Package builds** job to finish successfully.
5. Open the completed workflow run and download the **Build Output** artifact. It should contain a combined `.geode` package for Windows and Android 32/64-bit.

If a build job fails, use that job's compiler log to fix the source before installing the package. This source targets Geometry Dash 2.2074 and Geode SDK 4.6.0 as declared in `mod.json`.

## Install on Android

Use the `.geode` package from the successful workflow artifact and install it with a Geode-compatible Geometry Dash Android setup. Back up your game data first. Do not treat this mod as leaderboard-safe: it changes gameplay input timing, and some lists prohibit such mods.
