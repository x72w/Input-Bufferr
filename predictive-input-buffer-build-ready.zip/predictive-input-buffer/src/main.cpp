// Predictive Input Buffer - Geode mod for Geometry Dash 2.2074 (Windows + Android)
//
// Behaviour (reimplemented from the console output of the original mod):
//  * Jump presses are held for up to N physics ticks (1 tick = 1/240 s = 0.25 frames @ 60fps).
//  * Non-wave: a held press is released into the game the moment it becomes valid
//    (player grounded / dashing / in a flight mode), or when the tick limit runs out.
//  * Wave: inputs are debounced - a toggle may not follow the previous one by fewer
//    than N ticks.
//  * Stages (cycle with F6 on desktop, or the pause-menu button on any platform):
//    2/2 -> 4/4 -> 8/8 -> 16/8 -> OFF       (all-limit / wave-limit, in ticks)

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/CCKeyboardDispatcher.hpp>

#include <algorithm>
#include <cstdint>
#include <deque>
#include <string>

using namespace geode::prelude;

namespace {
	struct Stage {
		int all;
		int wave;
	};

	constexpr Stage STAGES[] = {{2, 2}, {4, 4}, {8, 8}, {16, 8}, {0, 0}};
	constexpr int STAGE_COUNT = 5;
	constexpr int OFF_STAGE = 4;
	constexpr double TICKS_PER_FRAME_60 = 4.0; // 240 Hz physics / 60 fps

	int g_stage = 0;
	bool g_stageInit = false;

	void ensureStageInit() {
		if (g_stageInit) return;
		g_stageInit = true;
		g_stage = std::clamp(static_cast<int>(Mod::get()->getSettingValue<int64_t>("start-stage")), 1, STAGE_COUNT) - 1;
	}

	std::string stageLabel(int s) {
		if (s == OFF_STAGE) return "OFF (100% raw input)";
		return fmt::format(
			"{} Ticks All | {} Ticks Wave ({:.1f}f / {:.1f}f @ 60fps)",
			STAGES[s].all, STAGES[s].wave,
			STAGES[s].all / TICKS_PER_FRAME_60, STAGES[s].wave / TICKS_PER_FRAME_60
		);
	}

	std::string stageShort(int s) {
		if (s == OFF_STAGE) return "OFF";
		return fmt::format("{}/{}", STAGES[s].all, STAGES[s].wave);
	}

	void cycleStage() {
		ensureStageInit();
		g_stage = (g_stage + 1) % STAGE_COUNT;
		log::info("[InputBuffer] F6 Cycle -> STAGE {}: {}", g_stage + 1, stageLabel(g_stage));
	}

	bool bufferEnabled() {
		return Mod::get()->getSettingValue<bool>("enabled");
	}

	// Would a jump press do something useful for this player right now?
	bool pressIsValid(PlayerObject* p) {
		if (!p) return true;
		// Flight-style modes react to input at any time.
		if (p->m_isShip || p->m_isBird || p->m_isDart || p->m_isSwing) return true;
		if (p->m_isDashing) return true;
		return p->m_isOnGround;
	}
}

struct Pending {
	bool down;
	int button;
	bool player1;
	uint64_t queuedTick;
};

class $modify(IBLayer, GJBaseGameLayer) {
	struct Fields {
		std::deque<Pending> queue[2]; // [0] = player 1, [1] = player 2
		uint64_t tick = 0;
		uint64_t lastApplied[2] = {0, 0};
		bool bypass = false;
	};

	void clearQueues() {
		auto f = m_fields.self();
		f->queue[0].clear();
		f->queue[1].clear();
		f->lastApplied[0] = f->lastApplied[1] = f->tick;
	}

	PlayerObject* playerFor(bool p1) {
		return p1 ? m_player1 : m_player2;
	}

	int limitFor(PlayerObject* p) {
		auto const& st = STAGES[g_stage];
		return (p && p->m_isDart) ? st.wave : st.all;
	}

	void applyNow(Pending const& e) {
		auto f = m_fields.self();
		f->bypass = true;
		GJBaseGameLayer::handleButton(e.down, e.button, e.player1);
		f->bypass = false;
		f->lastApplied[e.player1 ? 0 : 1] = f->tick;
	}

	void handleButton(bool down, int button, bool isPlayer1) {
		ensureStageInit();
		auto f = m_fields.self();

		bool passThrough = f->bypass || !bufferEnabled() || g_stage == OFF_STAGE || button != 1;
		if (passThrough) {
			GJBaseGameLayer::handleButton(down, button, isPlayer1);
			if (!f->bypass) f->lastApplied[isPlayer1 ? 0 : 1] = f->tick;
			return;
		}

		int idx = isPlayer1 ? 0 : 1;
		auto* player = playerFor(isPlayer1);
		bool wave = player && player->m_isDart;
		auto& q = f->queue[idx];

		// Keep ordering: once something is waiting, everything queues behind it.
		if (q.empty()) {
			if (wave) {
				bool ready = (f->tick - f->lastApplied[idx]) >= static_cast<uint64_t>(limitFor(player));
				if (ready) {
					GJBaseGameLayer::handleButton(down, button, isPlayer1);
					f->lastApplied[idx] = f->tick;
					return;
				}
			} else if (!down || pressIsValid(player)) {
				GJBaseGameLayer::handleButton(down, button, isPlayer1);
				f->lastApplied[idx] = f->tick;
				return;
			}
		}

		q.push_back({down, button, isPlayer1, f->tick});
	}

	void processCommands(float dt) {
		ensureStageInit();
		auto f = m_fields.self();
		f->tick++;

		for (int idx = 0; idx < 2; ++idx) {
			auto& q = f->queue[idx];
			auto* player = playerFor(idx == 0);

			// Settings/stage changed mid-level: flush so nothing gets stuck.
			if (g_stage == OFF_STAGE || !bufferEnabled()) {
				while (!q.empty()) {
					applyNow(q.front());
					q.pop_front();
				}
				continue;
			}

			while (!q.empty()) {
				Pending e = q.front();
				bool wave = player && player->m_isDart;
				int limit = limitFor(player);
				uint64_t waited = f->tick - e.queuedTick;
				bool fire = false;

				if (wave) {
					fire = (f->tick - f->lastApplied[idx]) >= static_cast<uint64_t>(limit) || waited >= static_cast<uint64_t>(limit);
				} else if (!e.down) {
					fire = true; // releases follow their press immediately
				} else {
					fire = pressIsValid(player) || waited >= static_cast<uint64_t>(limit);
				}

				if (!fire) break;

				q.pop_front();
				applyNow(e);

				if (e.down && waited > 0 && Mod::get()->getSettingValue<bool>("verbose")) {
					log::info(
						"[InputBuffer] *** SAVED +{} TICKS ({:.2f} frames @ 60fps) PRESS! [Limit: {}] ***",
						waited, waited / TICKS_PER_FRAME_60, limit
					);
				}
			}
		}

		GJBaseGameLayer::processCommands(dt);
	}
};

class $modify(IBPlayLayer, PlayLayer) {
	void resetLevel() {
		PlayLayer::resetLevel();
		static_cast<IBLayer*>(static_cast<GJBaseGameLayer*>(this))->clearQueues();
	}
};

class $modify(IBPauseLayer, PauseLayer) {
	void customSetup() {
		PauseLayer::customSetup();
		if (!Mod::get()->getSettingValue<bool>("pause-button")) return;
		ensureStageInit();
		this->customSetupBufferButton();
	}

	void customSetupBufferButton() {
		auto winSize = CCDirector::get()->getWinSize();
		auto menu = CCMenu::create();
		menu->setPosition({0, 0});
		menu->setID("input-buffer-menu"_spr);
		auto spr = ButtonSprite::create(fmt::format("Buffer: {}", stageShort(g_stage)).c_str(), "goldFont.fnt", "GJ_button_04.png", .7f);
		auto btn = CCMenuItemExt::createSpriteExtra(spr, [this](CCObject*) {
			cycleStage();
			if (auto m = this->getChildByID("input-buffer-menu"_spr)) m->removeFromParent();
			this->customSetupBufferButton();
		});
		btn->setPosition({70.f, winSize.height - 30.f});
		menu->addChild(btn);
		this->addChild(menu, 100);
	}
};

#ifndef GEODE_IS_MOBILE
class $modify(IBKeyboard, CCKeyboardDispatcher) {
	bool dispatchKeyboardMSG(enumKeyCodes key, bool down, bool repeat, double timestamp) {
		if (down && !repeat && key == KEY_F6 && PlayLayer::get()) {
			cycleStage();
		}
		return CCKeyboardDispatcher::dispatchKeyboardMSG(key, down, repeat, timestamp);
	}
};
#endif

$on_mod(Loaded) {
	ensureStageInit();
	log::info("[InputBuffer] Starting Mode: STAGE {} ({})", g_stage + 1, stageShort(g_stage));
	log::info("[InputBuffer] Cycle: 2/2 -> 4/4 -> 8/8 -> 16/8 -> OFF (F6 on desktop, pause menu button everywhere)");
}
