# Predictive Input Buffer

Geode mod for Geometry Dash 2.2074, targeting Windows and Android (32 and 64 bit).

## What it does

Jump presses are held for up to N physics ticks (1 tick = 1/240 s = 0.25 frames at 60 fps).

- **Normal gamemodes:** a held press is delivered the moment it becomes useful (player on the ground, dashing, or in a flight mode), or when the tick limit runs out.
- **Wave:** inputs are debounced, so a toggle can't follow the previous one by fewer than N ticks.
- **Stages** (all-limit / wave-limit): `2/2 -> 4/4 -> 8/8 -> 16/8 -> OFF`
- Console output matches the original style, e.g. `*** SAVED +2 TICKS (0.50 frames @ 60fps) PRESS! [Limit: 4] ***`

## Controls

- **Desktop:** F6 in a level cycles stages.
- **Desktop and Android:** a "Buffer: x/y" button in the pause menu cycles stages.
- Settings: enable switch, starting stage, logging, pause button.

## Building

1. Install the Geode SDK and CLI, set `GEODE_SDK`.
2. `geode build` in this folder. Or push to GitHub: the included workflow builds Windows + Android 32/64 and uploads one combined `.geode` file.

## Notes

- This is a reimplementation inferred from console output, not the original source. The wave behaviour and the "valid press" rule are my interpretation.
- Not yet compiled. Hook signatures (`handleButton`, `processCommands`, `CCKeyboardDispatcher::dispatchKeyboardMSG`) follow the 2.2074 bindings as I know them; if the build complains, check them against `geode-sdk/bindings`.
- Ring/pad clicks aren't specially handled; GD already buffers those.
- Input-altering mods are banned by many demon lists and leaderboards. Don't submit records using it without checking rules.
